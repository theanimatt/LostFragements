import {ctx, canvas} from "./script2.js";
import {Sprite} from "./sprite.js";


class Player extends Sprite{            // Player class extends Sprite class (inheritance)
    constructor({                                          // constructor function with object as parameter
        collisionBlocks = [], spikes = [], imageSrc, frameRate, animations, loop, }) { // default parameters
        super({imageSrc, frameRate, animations, loop,});     // super() calls the constructor of the parent class
        this.position = {                           // this is the player's position
            x: 650,
            y: 660
        };

        this.velocity = {                           // this is the player's velocity
            x: 0,
            y: 0
        };

        this.sides = {                          // this is the player's sides (hitbox)
            bottom: this.position.y + this.height, // bottom side of player
        }
        this.gravity = 0.85;                // this is the player's gravity

        this.collisionBlocks = collisionBlocks; // this is the player's collision blocks
        this.spikes = spikes;                  // not used in this game
    }
    update() {                          // update function for player class

        this.position.x += this.velocity.x;
        this.updateHitBox();
        this.checkHorizontalCollision();

        this.velocity.y += this.gravity;
        this.position.y += this.velocity.y;
        this.updateHitBox();


       ctx.fillRect(                    // draws the hitbox of the player
          this.hitbox.position.x,
          this.hitbox.position.y,
           this.hitbox.width,
           this.hitbox.height
        );
        this.checkVerticalCollision();

    }

    handleInput(keys){          // handles the input of the player and changes the sprite
        if (this.preventInput) return;
        this.velocity.x = 0;
        if (keys.d.pressed) {
            this.switchSprite('runRight');
            this.velocity.x = 3.5;
            this.lastDirection = 'right';}
        else if (keys.a.pressed){
            this.switchSprite('runLeft');
            this.velocity.x = -3.5;
            this.lastDirection = 'left';}
        else if(keys.w.pressed){
            if (this.lastDirection === 'right') {
                this.switchSprite('jumpRight');
                this.velocity.y = 0.2;
                this.velocity.x = 3.5;
                this.lastDirection = 'right';}
            else {
                this.switchSprite('jumpLeft');
                this.velocity.y = 0.2;
                this.velocity.x = -3.5;
            }
        }
        else {
            if (this.lastDirection === 'right') this.switchSprite('idleRight');
            else this.switchSprite('idleLeft');
        }
    };

    switchSprite(name){             // switches the sprite of the player to the given name
        if (this.image === this.animations[name].image) return;  // if the image is already the same, return
        this.currentFrame = 0;                                 // resets the current frame to 0
        this.image = this.animations[name].image;
        this.frameRate = this.animations[name].frameRate;
        this.frameBuffer = this.animations[name].frameBuffer;
        this.loop = this.animations[name].loop;
        this.currentAnimation = this.animations[name];
    }

    updateHitBox(){             // updates the hitbox of the player to the current position
        this.hitbox = {
            position: {
                x: this.position.x+15,
                y: this.position.y,
            },
            width: 30,
            height: 60,
        }
    }

    checkHorizontalCollision(){         // checks if the player collides with a block or spike from the left or right
        for (let i = 0; i < this.collisionBlocks.length; i++) {     // loops through all collision blocks in the level
            const collisionBlock = this.collisionBlocks[i];             // sets the current collision block to a variable

            if (                                                        // checks if the player collides with a block
                this.hitbox.position.x <= collisionBlock.position.x + collisionBlock.width &&
                this.hitbox.position.x + this.hitbox.width >= collisionBlock.position.x &&
                this.hitbox.position.y + this.hitbox.height >= collisionBlock.position.y &&
                this.hitbox.position.y <= collisionBlock.position.y + collisionBlock.height &&
                collisionBlock.type === 'block'
            ) {
                if (this.velocity.x < 0){                           // if the player collides with the left side of the block
                    console.log('left hit');
                    const offset = this.hitbox.position.x - this.position.x; // calculates the offset
                    this.position.x = collisionBlock.position.x + collisionBlock.width - offset + 0.01; // sets the player's position to the block's position - the offset
                    break;
                }
                if (this.velocity.x > 0){                   // if the player collides with the right side of the block
                    console.log('right hit');
                    const offset  = this.hitbox.position.x - this.position.x +
                        this.hitbox.width;
                    this.position.x = collisionBlock.position.x - offset -0.01; // sets the player's position to the block's position - the offset
                    break;
                }
            } else if (                                                     // checks if the player collides with a spike
                this.hitbox.position.x <= collisionBlock.position.x + collisionBlock.width &&
                this.hitbox.position.x + this.hitbox.width >= collisionBlock.position.x &&
                this.hitbox.position.y + this.hitbox.height >= collisionBlock.position.y &&
                this.hitbox.position.y <= collisionBlock.position.y + collisionBlock.height &&
                collisionBlock.type === 'spike'
            ) {
                if (this.velocity.x < 0){               // if the player collides with the left side of the spike set the player's position to the start of the level
                    console.log('spike left hit');
                    this.velocity.x = 0;
                    this.position.x = 100;
                    this.position.y = 660;
                    break;
                }
                if (this.velocity.x > 0){           // if the player collides with the right side of the spike set the player's position to the start of the level
                    console.log('spike right hit');
                    this.velocity.x = 0;
                    this.position.x = 100;
                    this.position.y = 660;
                    break;
                }
            }
        }
    }
    checkVerticalCollision(){                   // checks if the player collides with a block or spike from the top or bottom
        for (let i = 0; i < this.collisionBlocks.length; i++) {
            const collisionBlock = this.collisionBlocks[i];

            if (                                        // checks if the player collides with a block
                this.hitbox.position.x <= collisionBlock.position.x + collisionBlock.width &&
                this.hitbox.position.x + this.hitbox.width >= collisionBlock.position.x &&
                this.hitbox.position.y + this.hitbox.height >= collisionBlock.position.y &&
                this.hitbox.position.y <= collisionBlock.position.y + collisionBlock.height &&
                collisionBlock.type === 'block'
            ) {
                if (this.velocity.y < 0){               // if the player collides with the top side of the block set the player's position to the block's position - the offset
                    console.log('top hit');
                    this.velocity.y = 0;
                    const offset = this.hitbox.position.y - this.position.y;
                    this.position.y = collisionBlock.position.y + collisionBlock.height - offset + 0.01;
                    break;
                }
                if (this.velocity.y > 0){                   // if the player collides with the bottom side of the block set the player's position to the block's position - the offset
                    console.log('bottom hit');
                    this.velocity.y = 0;
                    const offset  = this.hitbox.position.y - this.position.y +
                    this.hitbox.height;
                    this.position.y = collisionBlock.position.y - offset - 0.01;
                    break;
                }

            } else if (                                         // checks if the player collides with a spike
                this.hitbox.position.x <= collisionBlock.position.x + collisionBlock.width &&
                this.hitbox.position.x + this.hitbox.width >= collisionBlock.position.x &&
                this.hitbox.position.y + this.hitbox.height >= collisionBlock.position.y &&
                this.hitbox.position.y <= collisionBlock.position.y + collisionBlock.height &&
                collisionBlock.type === 'spike'
            ) {
                if (this.velocity.y < 0){            // if the player collides with the top side of the spike set the player's position to the start of the level
                    console.log('spike top hit');
                    this.velocity.y = 0;
                    this.position.y = 660;
                    this.position.x = 100;
                    break;
                }
                if (this.velocity.y > 0){           // if the player collides with the bottom side of the spike set the player's position to the start of the level
                    console.log('spike bottom hit');
                    this.velocity.y = 0;
                    this.position.y = 660;
                    this.position.x = 100;
                    break;
                }
            }
        }
    }
}


export {Player}