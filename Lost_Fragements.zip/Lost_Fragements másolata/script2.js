import { Player } from "./player.js";
import { Sprite } from "./sprite.js";
import {
    collisionLevel1,
    CollisionBlock,
    collisionLevel4,
    collisionLevel3,
    collisionLevel2,
    Spike,
    collisionLevel0,
    collisionLevel5
} from "./data.js";

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

canvas.width = 1368;
canvas.height = 768;

let parsedCollision; // 2D array
let collisionBlocks; // 1D array
let backgroundLevel; // Sprite
let crystals; // Sprite


Array.prototype.parse = function () { // 1D array to 2D array (38 is the width of the level)
    const rows = [];
    for (let i = 0; i < this.length; i += 38) {
        rows.push(this.slice(i, i + 38));
    }
    return rows;
}

Array.prototype.createObjectsFrom2D = function () { // 2D array to 1D array of objects (CollisionBlock)
    const objects = [];
    this.forEach((row, y) => {
        row.forEach((symbol, x) => {
            if (symbol === 38) {                            // 38 is the symbol for a collision block
                objects.push(new CollisionBlock({           // CollisionBlock is a class that extends Sprite
                    position: {
                        x: x * 36,
                        y: y * 32
                    },
                    type: 'block'
                }));
            } else if (symbol === 4) {                      // 4 is the symbol for a spike block
                objects.push(new Spike({                // Spike is a class that extends Sprite
                    position: {
                        x: x * 36,
                        y: y * 32
                    },
                    type: 'spike'
                }));
            }
        });
    });
    return objects;
}


export const player = new Player({ // Player is a class that extends Sprite
    imageSrc: "./sprites/idleRight3.png", // imageSrc is the default image for the player
    frameRate: 6,                           // frameRate is the number of frames in the sprite sheet
    animations: {                           // animations is an object that contains all the animations for the player
        idleRight: {                            // idleRight is the main animation for the player when he is idle and facing right
            frameRate: 6,
            frameBuffer: 25,
            loop: true,
            imageSrc: "./sprites/idleRight3.png",
        },
        idleLeft: {                            // idleLeft is the main animation for the player when he is idle and facing left
            frameRate: 6,
            frameBuffer: 25,
            loop: true,
            imageSrc: "./sprites/idleLeft3.png",
        },
        runRight: {                             // runRight is the main animation for the player when he is running and facing right
            frameRate: 6,
            frameBuffer: 20,
            loop: true,
            imageSrc: "./sprites/runRight3.png",
        },
        runLeft: {                              // runLeft is the main animation for the player when he is running and facing left
            frameRate: 6,
            frameBuffer: 20,
            loop: true,
            imageSrc: "./sprites/runLeft3.png",
        },
        jumpRight: {                            // jumpRight is the main animation for the player when he is jumping and facing right
            frameRate: 6,
            frameBuffer: 20,
            loop: true,
            imageSrc: "./sprites/jumpRight.png",
        },
        jumpLeft: {                             // jumpLeft is the main animation for the player when he is jumping and facing left
            frameRate: 6,
            frameBuffer: 20,
            loop: true,
            imageSrc: "./sprites/jumpLeft.png",
        },
        LevelComplete: {                            // LevelComplete is the main animation for the player when finishing a level
            frameRate: 6,
            frameBuffer: 20,
            loop: false,
            imageSrc: "./sprites/LevelComp.png",
            onCompleted: () => {                // onCompleted is a function that is called when the animation is completed
                console.log('Level Complete');
                for (let i = 0; i < 10; i++) {      // this loop is for the overlay effect its just a black screen that fades in and out
                    setTimeout(() => {
                        overlay.opacity += 0.1;
                    }, i * 100)
                }
                for (let i = 0; i < 10; i++) {
                   setTimeout(() => {
                        overlay.opacity -= 0.1;
                    }, i * 100 + 1000)
                }
                setTimeout(() => {          // this timeout is for the level transition
                    level++;
                    levels[level].init();
                    player.switchSprite('idleRight');
                    player.preventInput = false;
                }, 1000);

            }

        }
    }
});

let level = 0;                      // level is the current level
let levels = {                          // levels is an object that contains all the levels
    0:{                                             // 0 is the starting level when the game starts
        init: () => {
            parsedCollision = collisionLevel0.parse(); // collisionLevel0 is a 2D array that contains the level data
            collisionBlocks = parsedCollision.createObjectsFrom2D(); // collisionBlocks is a 1D array that contains all the collision blocks in the level
            player.collisionBlocks = collisionBlocks; // player.collisionBlocks is a 1D array that contains all the collision blocks that the player can collide with

            if (player.currentAnimation) player.currentAnimation.isActive = false;  // player.currentAnimation.isActive is a boolean that is used to check if the animation is completed

            player.switchSprite('idleRight');
            backgroundLevel = new Sprite({
                position: {
                    x: 0,
                    y: 0
                },
                imageSrc: "./imges/mainLevel.png"
            });
            crystals = [
                new Sprite({
                    position: {
                        x: 630,
                        y: 520
                    },
                    imageSrc: "./sprites/start.png",
                    frameRate: 6,
                    frameBuffer: 40,
                }),
            ]
        }
    },

    1:{                                            // 1 is the first level in the game
        init: () => {
            parsedCollision = collisionLevel1.parse();
            collisionBlocks = parsedCollision.createObjectsFrom2D();
            player.collisionBlocks = collisionBlocks;

            if (player.currentAnimation) player.currentAnimation.isActive = false;

            player.switchSprite('idleRight');
            backgroundLevel = new Sprite({
                position: {
                    x: 0,
                    y: 0
                },
                imageSrc: "./imges/level1.png"
            });
            crystals = [
                    new Sprite({
                        position: {
                            x: 1200,
                            y: 80
                        },
                        imageSrc: "./sprites/crystal.png",
                        frameRate: 6,
                        frameBuffer: 40,
                    }),
            ]
        }
    },
    2:{                                            // 2 is the second level in the game
        init: () => {
            parsedCollision = collisionLevel2.parse();
            collisionBlocks = parsedCollision.createObjectsFrom2D();
            player.collisionBlocks = collisionBlocks;
            player.position.x = 30;
            player.position.y = 600;

            if (player.currentAnimation) player.currentAnimation.isActive = false;

            backgroundLevel = new Sprite({
                position: {
                    x: 0,
                    y: 0
                },
                imageSrc: "./imges/level2.png"
            });
            crystals = [
                new Sprite({
                    position: {
                        x: 560,
                        y: 20
                    },
                    imageSrc: "./sprites/crystal2.png",
                    frameRate: 6,
                    frameBuffer: 40,
                }),
            ]
        }
    },
    3:{                                       // 3 is the third level in the game
        init: () => {
            parsedCollision = collisionLevel3.parse();
            collisionBlocks = parsedCollision.createObjectsFrom2D();
            player.collisionBlocks = collisionBlocks;
            player.position.x = 30;
            player.position.y = 600;

            if (player.currentAnimation) player.currentAnimation.isActive = false;

            backgroundLevel = new Sprite({
                position: {
                    x: 0,
                    y: 0
                },
                imageSrc: "./imges/level3.png"
            });
            crystals = [
                new Sprite({
                    position: {
                        x: 1230,
                        y: 570
                    },
                    imageSrc: "./sprites/crystal3.png",
                    frameRate: 6,
                    frameBuffer: 40,
                }),
            ]
        }
    },
    4 :{                               // 4 is the fourth level in the game
        init: () => {
            parsedCollision = collisionLevel4.parse();
            collisionBlocks = parsedCollision.createObjectsFrom2D();
            player.collisionBlocks = collisionBlocks;
            player.position.x = 30;
            player.position.y = 600;

            if (player.currentAnimation) player.currentAnimation.isActive = false;

            backgroundLevel = new Sprite({
                position: {
                    x: 0,
                    y: 0
                },
                imageSrc: "./imges/level4.png"
            });
            crystals = [
                new Sprite({
                    position: {
                        x: 30,
                        y: 50
                    },
                    imageSrc: "./sprites/crystal4.png",
                    frameRate: 6,
                    frameBuffer: 40,
                }),
            ]
        }

    },
    5: {                           // 5 is the end screen when the player finishes the game
        init: () => {
            parsedCollision = collisionLevel5.parse();
            collisionBlocks = parsedCollision.createObjectsFrom2D();
            player.collisionBlocks = collisionBlocks;
            player.position.x = 30;
            player.position.y = 1900;

            if (player.currentAnimation) player.currentAnimation.isActive = false;

            backgroundLevel = new Sprite({
                position: {
                    x: 0,
                    y: 0
                },
                imageSrc: "./imges/won.png"
            });
            crystals = [
                new Sprite({
                    position: {
                        x: 2230,
                        y: 1570
                    },
                    imageSrc: "./sprites/crystal4.png",
                    frameRate: 6,
                    frameBuffer: 40,
                }),
            ]
        }
    }

}



const keys ={               // keys is an object that contains all the keys that the player can press
    w: { pressed: false, },
    a: { pressed: false, },
    d: { pressed: false, },
}

const overlay = { // overlay is an object that contains the overlay effect
    opacity: 0,
}

function animate() {        // animate is the main function that is called every frame, it draws all the sprites and updates them
    window.requestAnimationFrame(animate); // this is a built in function that calls the animate function every frame

    backgroundLevel.draw();
    collisionBlocks.forEach(collisionBlock => {
        collisionBlock.draw();
    });

    crystals.forEach(crystal => {
        crystal.draw();
    });

    player.handleInput(keys); // this function is called every frame to check if the player pressed any keys
    player.draw();           // this function is called every frame to draw the player
    player.update();        // this function is called every frame to update the player

    ctx.save();         // this is the overlay effect
    ctx.globalAlpha = overlay.opacity;
    ctx.fillStyle = 'black';
    ctx.fillRect(0,0, canvas.width, canvas.height);
    ctx.restore();

}
levels[level].init();
animate();

addEventListener('keydown', (event) => { // this event listener is used to check if the player pressed any keys
    if (player.preventInput) return;                                    // player.preventInput is a boolean that is used to prevent the player from moving when he finishes a level
    switch (event.key) {
        case 'w':
            for(let i = 0; i < crystals.length; i++){           // this loop is used to check if the player is colliding with a crystal when he jumps
                const crystal = crystals[i];

                if (                                                            // this is the collision detection algorithm
                    player.hitbox.position.x + player.hitbox.width <= crystal.position.x + crystal.width &&
                    player.hitbox.position.x >= crystal.position.x &&
                    player.hitbox.position.y + player.hitbox.height >= crystal.position.y &&
                    player.hitbox.position.y <= crystal.position.y + crystal.height
                ) {
                    player.velocity.y = 0;                                  // this is the collision response algorithm
                    player.velocity.x = 0;
                    player.preventInput = true;
                    player.switchSprite('LevelComplete');                   // this is used to switch the player animation to the LevelComplete animation
                    return;
                }
            }
            if (player.velocity.y === 0) player.velocity.y = -16;               // this is used to make the player jump when he is on the ground and not colliding with a crystal

            break;
        case 'a':                                                          // this is used to make the player move left
            keys.a.pressed = true;
            break;
        case 'd':                                                      // this is used to make the player move right
            keys.d.pressed = true;
            break;
    }
});

addEventListener('keyup', (event) => {                     // this event listener is used to check if the player released any keys
    switch (event.key) {
        case 'a':
            keys.a.pressed = false;
            break;
        case 'd':
            keys.d.pressed = false;
            break;
    }
});

export { canvas, ctx };